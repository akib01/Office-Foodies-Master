## Office Foodies -  Food For Your Workplace

#### [LIVE DEMO: http://backendsandbox.tk/office-foodies/](http://backendsandbox.tk/office-foodies/)


## Technology
A raw php Custom MVC with hand built ORM, url router, and structure. 
Mockaroo data seeding.
[webtech class project]

## Details
An organized food service for organized people.

As a Office Employee:
    Vote on foods with colleages, Suggest Food, See Whats Popular
    
    Sample Mock Data Provided For: 
     	Email: fcarolan2h@shareasale.com  Password: a12345
    
As a Office Manager:
    See what food employees have voted today, place orders, vendors will bid on your orders,
    choose the bid you want, pay via Bkash or on delivery.
    Add employees to office, see employee list, See order history.
    
    Sample Mock Data Provided For: 
     	Email: fbrasner2q@nba.com  Password: a12345

As a Vendor:
    See food orders by offices, Bid on orders, Deliver won bids, See delivery list.
    
    Sample Mock Data Provided For: 
    	 Email: Sifat3d@gmail.com  Password: a12345 
    
## Group

* Chowdhury, MD. Sohan
* Rahman, MD. Habibur
* Sadman Shakib
* Akib

