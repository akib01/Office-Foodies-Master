<?php

//require_once("Model.php");

class FoodList extends Model
{
    public static function tableName(){
        return "foodlist";
    }
}