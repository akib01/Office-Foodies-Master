<html>
 <body>
  <h2>Welcome</h2>
  <h3>Data is <?=$data['name']?> </h3>
 </body>
</html>