<?php include("header.html") ?>
 
  <form action="adduser">
		<label>User Email</label>
		<input placeholder="emp@example.com" name="useremail"/>

	  <input type="submit" value="submit">
  </form>
</td>

<?php include("footer.html") ?>
