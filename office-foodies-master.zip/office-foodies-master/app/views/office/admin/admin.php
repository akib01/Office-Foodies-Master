<?php include("header.html") ?>
  <h2>Tiger it</h2>
  <form >
  	<input type="submit" value="add new food">
  </form>


</td>

<?php include("footer.html") ?>
