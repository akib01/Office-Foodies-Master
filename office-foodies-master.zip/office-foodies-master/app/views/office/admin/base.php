<?php include("header.html") ?>
<h2> Page </h2> 
<h4>I am at the other parts of the world which are not part of the glorious UKN.
We are ashamed of ourselves. </h4>
</td>

<?php include("footer.html") ?>
