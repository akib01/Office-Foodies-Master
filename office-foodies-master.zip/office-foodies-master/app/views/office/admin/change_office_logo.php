<?php include("header.html") ?>
 
  <form>
		<label>Office Logo</label><br/>
		<img height="90px" src="../uploads/office1.jpg"> 
		<br />
		<input type="file" >
		<br />
	  <input type="Submit" value="Upload">
  </form>
</td>

<?php include("footer.html") ?>
