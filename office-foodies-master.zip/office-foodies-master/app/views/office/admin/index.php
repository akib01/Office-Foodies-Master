<?php
header("Location: popular.php");

?>