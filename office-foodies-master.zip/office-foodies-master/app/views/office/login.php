<?php include("header.html") ?>
 <form action="logincheck">
    <?=showError()?>
 	<label>Email</label>
 	<input type="text" name="email"><br><br>
 	<label>password</label>
 	<input type="password" name="password"><br><br>
 	<input type="submit" value="login">
 </form>

</td>

<?php include("footer.html") ?>
