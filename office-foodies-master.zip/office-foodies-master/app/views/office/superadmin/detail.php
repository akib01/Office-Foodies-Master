<?php include("header.html") ?>

<fieldset>
 	 <label>Office Name</label><br /> XXXX <br />
	 <label>Delivery Address</label><br /> YYYY, 232aSDD, DADSD , asd asd, Dhaka<br />
	</fieldset>
	 
	<fieldset>
		<legend>Person who will manage the account of this office</legend>
 	<label>Name: </label>
 	XXA ASA<br />
	 <label>Email: </label>
	 a@b.com<br />
 	<label>User Name: </label>
 	assdas<br />

	 <label>Phone: </label>2323232323<br />
</fieldset>

<?php include("footer.html") ?>
