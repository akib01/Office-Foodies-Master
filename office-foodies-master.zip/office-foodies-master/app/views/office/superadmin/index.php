<?php include("header.html") ?>

  <h2>23 offices are active today</h2>
  <h2>7 vendors active today</h2>
  <h2>3 successfull deliveries today</h2>


</td>

<?php include("footer.html") ?>
