<?php include("header.html") ?>



<input placeholder="Search"/>
<select>
	<option>Date</option>
	<option>Company</option>
	<option>Vendor</option>
</select>
<button> Find </button>

<table border="0" cellspacing="0" cellpadding="0">
 	<tr>
		 <th>Vendor Name</th>
		 <th>Company Name</th>
		 <th>Order</th>
		 <th>Amount</th>
 	</tr>
 	<tr>
		 <td><a href="#">Rahim Foods</a></td>
		 <td><a href="#">DataSoft</a></td>
		 <td>Kacchi Biriyani</td>
		 <td>5000BDT</td>
		 </td>
 	</tr>
	 <tr>
	 <td><a href="#">Rahim Foods</a></td>
	 <td><a href="#">DataSoft</a></td>
	 <td>Kacchi Biriyani</td>
	 <td>5000BDT</td>
	 </td>
	 </tr>
	 <tr>
	 <td><a href="#">Rahim Foods</a></td>
	 <td><a href="#">DataSoft</a></td>
	 <td>Kacchi Biriyani</td>
	 <td>5000BDT</td>
	 </td>
	 </tr>
	 <tr>
	 <td><a href="#">Rahim Foods</a></td>
	 <td><a href="#">DataSoft</a></td>
	 <td>Kacchi Biriyani</td>
	 <td>5000BDT</td>
	 </td>
	 </tr>
	 <tr>
	 <td><a href="#">Rahim Foods</a></td>
	 <td><a href="#">DataSoft</a></td>
	 <td>Kacchi Biriyani</td>
	 <td>5000BDT</td>
	 </td>
 	</tr>

 	
 </table>
</td>

<?php include("footer.html") ?>
