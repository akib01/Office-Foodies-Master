<?php include("header.html") ?>
<h2> Suggest A Menu </h2> 

<label>Your Requested Item</label>
<input type="text">
<br>
<input type="submit" value="submit">

</td>

<?php include("footer.html") ?>
