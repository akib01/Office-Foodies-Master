<?php
header("Location: today.php");

?>